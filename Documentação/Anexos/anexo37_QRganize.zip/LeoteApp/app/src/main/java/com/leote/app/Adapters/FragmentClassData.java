
/*  Coded by Henrique Leote - 2019/2020   */

//É classe é responsavel pela transferência de dados de um Fragment para outro

package com.leote.app.Adapters;


//Declaração das váriaveis da classe "FragmentClassData"
public class FragmentClassData {
    public static String value;
    public static String value2;
}
